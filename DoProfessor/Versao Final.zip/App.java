import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;
import java.util.TreeSet;
import java.nio.charset.StandardCharsets;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

public class App extends Application {
    public enum Estados {
        ABERTURA, JOGO, PERDEU, GANHOU, JOGADORES2, JOGADOR1
    }

    public enum Dificuldade {
        FACIL, MEDIO, DIFICIL
    }

    private ColorPinLine senhaSecreta;
    private TextField tfNome;
    private TextField tfNome2;

    private List<LinhaJogo> linhasDeJogo;
    private int jogadaAndamento;
    GridPane grid;

    private Scene sceneJogada;
    private Scene sceneAbertura;
    private Scene sceneSenhaNome;
    private Scene sceneGanhou;
    private Scene scenePerdeu;
    private Stage primaryStage;

    int nl = 2;
    int qualLinha = 1;

    private int numTentativas = 0;
    private int tentativasCorrente = 0;
    private int nivelDificuldade = 0;
    long tempoInicial;
    long tempoFinal;

    private String quantJogagores = "";
    private String adver = " ";

    private boolean ganhouBool = false;
    private boolean demo = false;

    private Scene montaCenaJogada() {
        // Monta a cena da jogada
        grid = new GridPane();
        grid.setAlignment(Pos.CENTER);
        grid.setHgap(20);
        grid.setVgap(10);
        grid.setPadding(new Insets(25, 25, 25, 25));

        // Define uma senha para a senha secreta
        senhaSecreta = new ColorPinLine();

        linhasDeJogo = new ArrayList<>();

        LinhaJogo l = LinhaJogo.criaLinhaJogo();
        linhasDeJogo.add(l);

        Button but = new Button("Fazer tentativa");
        but.setOnAction(e -> verificaSenha(e));
        Button btVolta = new Button("Voltar para tela inicial");
        btVolta.setOnAction(e -> trocaTela(Estados.ABERTURA));

        grid.add(linhasDeJogo.get(0), 0, nl);

        grid.add(but, 1, 14);
        grid.add(btVolta, 0, 14);

        linhasDeJogo.get(0).getTentativa().unblock();
        return new Scene(grid, 600, 200);

    }

    public void caso1Jogador() {
        quantJogagores = "individual";
        senhaSecreta.unblock();
        List<Cor> listaCor = Arrays.asList(Cor.values());
        Collections.shuffle(listaCor);
        Cor[] vetorAux = new Cor[9];
        int cont = 0;
        for (int i = 0; i < 9; i++) {
            if (listaCor.get(i) != Cor.BRANCO && listaCor.get(i) != Cor.PRETO) {
                vetorAux[cont] = listaCor.get(i);
                cont++;
            }
        }
        for (int i = 0; i < ColorPinLine.QTDADE; i++) {
            senhaSecreta.setCor(vetorAux[i], i);
        }
        senhaSecreta.block();
        GridPane gridSenha = new GridPane();

        gridSenha.setAlignment(Pos.CENTER);
        gridSenha.setHgap(20);
        gridSenha.setVgap(10);
        gridSenha.setPadding(new Insets(100, 100, 100, 100));

        Button demo = new Button("Jogar na versão demo");
        gridSenha.add(demo, 0, 9);
        demo.setOnAction(e -> versaoDemoTrue1jogador());

        gridSenha.add(new Label("Dificuldade do jogo: "), 0, 2);
        Button easy = new Button("Facil");
        gridSenha.add(easy, 1, 2);
        easy.setOnAction(e -> dificuldadeJogo(1));
        Button medium = new Button("Medio");
        gridSenha.add(medium, 2, 2);
        medium.setOnAction(e -> dificuldadeJogo(2));
        Button hard = new Button("Dificil");
        gridSenha.add(hard, 3, 2);
        hard.setOnAction(e -> dificuldadeJogo(3));

        adver = "PC";

        gridSenha.add(new Label("Seu nome: "), 1, 0);
        tfNome = new TextField();
        gridSenha.add(tfNome, 2, 0);
        Button definir = new Button("prosseguir");
        gridSenha.add(definir, 4, 9);
        definir.setOnAction(e -> trocaTela(Estados.JOGO));
        sceneSenhaNome = new Scene(gridSenha);

    }

    boolean aux = false;
    List<Cor> senha;
    ColorPinLine senhaDefinir;

    TreeSet<Cor> verificaIgualdade;

    public void capturaSenha() {
        adver = tfNome2.getText();
        for (int i = 0; i < ColorPinLine.QTDADE; i++) {
            senha.add(senhaDefinir.getColors().get(i));
        }
        verificaIgualdade = new TreeSet<>();
        for (int i = 0; i < ColorPinLine.QTDADE; i++) {
            verificaIgualdade.add(senha.get(i));
            senhaSecreta.setCor(senha.get(i), i);
        }
        senhaSecreta.block();
        trocaTela(Estados.JOGO);
    }

    public void caso2Jogadores() {
        quantJogagores = "multiplayer";
        senhaSecreta.unblock();
        senhaDefinir = new ColorPinLine();
        GridPane gridSenha = new GridPane();
        gridSenha.setAlignment(Pos.CENTER);
        gridSenha.setHgap(20);
        gridSenha.setVgap(10);
        gridSenha.setPadding(new Insets(100, 100, 100, 100));
        gridSenha.add(new Label("Dificuldade do jogo: "), 0, 8);
        Button easy = new Button("Facil");
        gridSenha.add(easy, 1, 8);
        easy.setOnAction(e -> dificuldadeJogo(1));
        Button medium = new Button("Medio");
        gridSenha.add(medium, 2, 8);
        medium.setOnAction(e -> dificuldadeJogo(2));
        Button hard = new Button("Dificil");
        gridSenha.add(hard, 3, 8);
        hard.setOnAction(e -> dificuldadeJogo(3));

        Button demo = new Button("jogar na versão demo");
        gridSenha.add(demo, 0, 10);

        gridSenha.add(new Label("Nome 1º jogador: "), 1, 4);
        tfNome = new TextField();
        gridSenha.add(tfNome, 2, 4);
        gridSenha.add(new Label("Nome 2º jogador: "), 1, 6);
        tfNome2 = new TextField();
        gridSenha.add(tfNome2, 2, 6);
        gridSenha.add(senhaDefinir, 1, 1);
        Button definir = new Button("definir senha, nome, dificuldade e prosseguir");
        gridSenha.add(definir, 4, 10);
        senha = new LinkedList<>();
        definir.setOnAction(e -> capturaSenha());
        demo.setOnAction(e -> versaoDemoTrue());
        sceneSenhaNome = new Scene(gridSenha);
    }

    

    public void versaoDemoTrue() {
        demo = true;
        capturaSenha();
    }

    public void versaoDemoTrue1jogador() {
        demo = true;
        trocaTela(Estados.JOGO);
    }

    public void versaoDemoFalse() {
        demo = false;
    }

    public void ganhouOuN() {
        ganhouBool = true;
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        this.primaryStage = primaryStage;

        tempoInicial = System.currentTimeMillis();
        sceneJogada = montaCenaJogada();

        GridPane gridA = new GridPane();
        gridA.setAlignment(Pos.CENTER);
        gridA.setHgap(20);
        gridA.setVgap(10);
        gridA.setPadding(new Insets(75, 75, 75, 75));
        Button forma1 = new Button("1 jogador");
        Button forma2 = new Button("2 jogadores");

        gridA.add(new Label("*Selecione a forma de jogar abaixo para prosseguir"), 0, 5);
        gridA.add(new Label("Forma de jogar: "), 0, 6);
        gridA.add(forma1, 1, 6);
        gridA.add(forma2, 2, 6);
        gridA.add(new Label("MINI SENHA JOGO "), 2, 0);

        forma2.setOnAction(e -> trocaTela(Estados.JOGADORES2));
        forma1.setOnAction(e -> trocaTela(Estados.JOGADOR1));
        sceneAbertura = new Scene(gridA);

        GridPane gridG = new GridPane();
        gridG.setAlignment(Pos.CENTER);
        gridG.setHgap(20);
        gridG.setVgap(10);
        gridG.setPadding(new Insets(100, 100, 100, 100));
        gridG.add(new Label("Você ganhou!!! "), 1, 1);
        Button verRecordes = new Button("Ver recordes");
        gridG.add(verRecordes, 4, 3);
        verRecordes.setOnAction(e -> lerRecordes());
        sceneGanhou = new Scene(gridG);

        GridPane gridP = new GridPane();
        gridP.setAlignment(Pos.CENTER);
        gridP.setHgap(20);
        gridP.setVgap(10);
        gridP.setPadding(new Insets(100, 100, 100, 100));
        gridP.add(new Label("Você perdeu, tente novamente "), 1, 1);
        Button verRecordesPerdeu = new Button("Ver recordes");
        gridP.add(verRecordesPerdeu, 4, 3);
        verRecordesPerdeu.setOnAction(e -> lerRecordes());
        gridP.add(new Label("A sequência da senha secreta era: "), 1, 2);
        gridP.add(senhaSecreta, 2, 2);
        scenePerdeu = new Scene(gridP);

        // Exibe a cena da abertura no palco
        primaryStage.setTitle("Inicio do jogo");
        primaryStage.setScene(sceneAbertura);
        primaryStage.show();
    }

    public void trocaTela(Estados est) {// muda manualmente a tela
        Scene s = null;
        String titulo = "";
        switch (est) {
            case JOGO:
                if (quantJogagores == "individual") {
                    if (tfNome.getLength() < 1 && nivelDificuldade == 0) {
                        Alert campoVazio = new Alert(Alert.AlertType.ERROR);
                        campoVazio.setTitle("Nível de dificuldade não informado e campo de nome não preenchido");
                        campoVazio.setHeaderText(
                                "O campo de nome não foi preenchido e nem foi selecionado o nível de dificuldade, esses campos são obrigatórios");
                        campoVazio.setContentText("clique em 'OK' para voltar para a tela das definições");
                        campoVazio.showAndWait();
                        versaoDemoFalse();
                        caso1Jogador();
                        s = sceneSenhaNome;
                        titulo = "Nome e dificuldade";
                        break;
                    }

                    else if (tfNome.getLength() < 1) {
                        Alert campoVazio = new Alert(Alert.AlertType.ERROR);
                        campoVazio.setTitle("Nome do jogador 1 vazio");
                        campoVazio.setHeaderText(
                                "O campo do nome do jogador não foi preenchido, esse campo é obrigatório");
                        campoVazio.setContentText("clique em 'OK' para voltar para a tela das definições");
                        campoVazio.showAndWait();
                        versaoDemoFalse();
                        caso1Jogador();
                        s = sceneSenhaNome;
                        titulo = "Nome e dificuldade";
                        break;
                    } else if (nivelDificuldade == 0) {
                        Alert campoVazio = new Alert(Alert.AlertType.ERROR);
                        campoVazio.setTitle("Nível de dificuldade não informado");
                        campoVazio
                                .setHeaderText("Não foi selecionado o nível de dificuldade, esse campo é obrigatório");
                        campoVazio.setContentText("clique em 'OK' para voltar para a tela das definições");
                        campoVazio.showAndWait();
                        versaoDemoFalse();
                        caso1Jogador();
                        s = sceneSenhaNome;
                        titulo = "Nome e dificuldade";
                        break;
                    }

                }
                if (quantJogagores == "multiplayer") {
                    int cont = 0;
                    if (verificaIgualdade.size() < 6) {
                        Alert campoVazio = new Alert(Alert.AlertType.ERROR);
                        campoVazio.setTitle("Cor repetida na senha");
                        campoVazio.setHeaderText("A senha não pode ter duas ou mais cores repetidas entre os pinos");
                        campoVazio.setContentText(
                                "clique em 'OK' para voltar para a tela das definições ou mostrar outros erros de preenchimento");
                        campoVazio.showAndWait();
                        versaoDemoFalse();
                        cont++;
                    }

                    if (tfNome.getLength() < 1 || tfNome2.getLength() < 1) {
                        Alert campoVazio = new Alert(Alert.AlertType.ERROR);
                        campoVazio.setTitle("Nome do jogador 1 e/ou nome do jogador 2 não informado(s)");
                        campoVazio.setHeaderText(
                                "O campo de nome dos jogadores não foi preenchido totalmente, esse(s) campo(s) é/são obrigatórios");
                        campoVazio.setContentText(
                                "clique em 'OK' para voltar para a tela das definições ou mostrar outros erros de preenchimento");
                        campoVazio.showAndWait();
                        versaoDemoFalse();
                        cont++;
                    }
                    if (nivelDificuldade == 0) {
                        Alert campoVazio = new Alert(Alert.AlertType.ERROR);
                        campoVazio.setTitle("Nível de dificuldade não informado");
                        campoVazio
                                .setHeaderText("Não foi selecionado o nível de dificuldade, esse campo é obrigatório");
                        campoVazio.setContentText(
                                "clique em 'OK' para voltar para a tela das definições ou mostrar outros erros de preenchimento");
                        campoVazio.showAndWait();
                        versaoDemoFalse();
                        cont++;
                    }
                    if (cont > 0) {
                        versaoDemoFalse();
                        caso2Jogadores();
                        s = sceneSenhaNome;
                        titulo = "Nome, dificuldade e senha";
                        break;
                    }

                }
                if(demo==true){
                    grid.add(senhaSecreta, 0, 1);
                }
                s = sceneJogada;
                titulo = "Jogo";
                break;

            case JOGADORES2:
                caso2Jogadores();
                s = sceneSenhaNome;
                titulo = "nome, dificuldade e definir senha";
                break;
            case JOGADOR1:
                caso1Jogador();
                s = sceneSenhaNome;
                titulo = "Nome e dificuldade";
                break;
            case ABERTURA:
                s = sceneAbertura;
                titulo = "Tela de abertura";
                break;
            case GANHOU:
                s = sceneGanhou;
                titulo = tfNome.getText() + " ganhou!";
                break;
            case PERDEU:
                s = scenePerdeu;
                titulo = tfNome.getText() + " perdeu!";
                break;

            default:
                break;
        }
        primaryStage.setTitle(titulo);
        primaryStage.setScene(s);
        primaryStage.show();
    }

    public void dificuldadeJogo(int opcao) {// dependendo da dificuldade, o jogador terá mais ou menos chances

        switch (opcao) {
            case 1:
                numTentativas = 12;
                nivelDificuldade = 47;
                break;
            case 2:
                numTentativas = 10;
                nivelDificuldade = 69;
                break;
            case 3:
                numTentativas = 8;
                nivelDificuldade = 93;
                break;
            default:
                break;
        }

    }

    public void verificaSenha(ActionEvent event) {
        ColorPinLine tentativa = linhasDeJogo.get(jogadaAndamento).getTentativa();
        BWPinLine pistas = linhasDeJogo.get(jogadaAndamento).getPista();
        int corretos = 0;
        int foraPos = 0;

        LinhaJogo l = LinhaJogo.criaLinhaJogo();
        linhasDeJogo.add(l);
        nl++;
        grid.add(linhasDeJogo.get(qualLinha), 0, nl);
        tentativasCorrente++;

        // Determina quantos pinos corretos e quantos fora de posição
        for (int i = 0; i < senhaSecreta.getChildren().size(); i++) {
            Pino pOrig = (Pino) senhaSecreta.getChildren().get(i);
            Pino pTent = (Pino) tentativa.getChildren().get(i);
            if (pOrig.getCor().equals(pTent.getCor())) {
                corretos++;
            } else {
                if (tentativa.getChildren().stream().map(p -> ((Pino) p).getCor()).filter(c -> c.equals(pOrig.getCor()))
                        .count() > 0) {
                    foraPos++;
                }
            }
        }

        int pos = 0;

        if (corretos == ColorPinLine.QTDADE) {
            ganhouOuN();
            tempoFinal = System.currentTimeMillis();
            if (demo == false) {
                escreveRecordes((17 - jogadaAndamento), getTempo(tempoInicial, tempoFinal));
            }
            trocaTela(Estados.GANHOU);
        }
        // Liga um pino preto para cada pino correto
        while (corretos > 0) {
            pistas.setPinPreto(pos);
            pos++;
            corretos--;
        }
        // Liga um pino branco para cada pino fora de posição
        while (foraPos > 0) {
            pistas.setPinBranco(pos);
            pos++;
            foraPos--;
        }
        // Desabilita os pinos restantes
        while (pos < pistas.getChildren().size()) {
            pistas.setEmpty(pos);
            pos++;
        }
        if (numTentativas > 0 && tentativasCorrente == numTentativas) {
            if (ganhouBool == true) {
                trocaTela(Estados.GANHOU);
            } else {
                trocaTela(Estados.PERDEU);
            }
            tentativasCorrente = 0;
        }
        tentativa.block();
        jogadaAndamento++;
        linhasDeJogo.get(qualLinha).getTentativa().unblock();
        qualLinha++;
    }

    public void lerRecordes() {
        LinkedList<ClasseRecordes> linhas = new LinkedList<>();
        String currDir = Paths.get("").toAbsolutePath().toString();
        String nameComplete = currDir + "\\" + "recordes.txt";
        Path path = Paths.get(nameComplete);
        try (Scanner sc = new Scanner(Files.newBufferedReader(path, StandardCharsets.UTF_8))) {
            while (sc.hasNext()) {
                String linha = sc.nextLine();
                if (linha.length() > 1) {
                    String[] dados = linha.split(";");
                    int pont = Integer.parseInt(dados[1]);
                    ClasseRecordes corrente = new ClasseRecordes(dados[0], pont, dados[2], dados[3]);
                    linhas.add(corrente);
                }
            }
        } catch (IOException x) {
            System.err.format("Erro de E/S: %s%n", x);
        }
        ClasseRecordes[] recordesOrdenado = linhas.toArray(new ClasseRecordes[0]);
        Arrays.sort(recordesOrdenado);
        String nomeAux = "";
        for (int i = 0; i < recordesOrdenado.length; i++) {
            if (recordesOrdenado[i].getNome().length() > nomeAux.length()) {
                nomeAux = recordesOrdenado[i].getNome();
            }
        }
        String linha = "";
        for (int i = 0; i < recordesOrdenado.length; i++) {
            if (i >= 10) {
                break;
            }
            linha += "\n" + (i + 1) + "º       " + String.format("%-20s %-25s %-1s", recordesOrdenado[i].getPontuacao(),
                    recordesOrdenado[i].getModo(), recordesOrdenado[i].getNome());
            linha += " / " + recordesOrdenado[i].getAdversario();

        }
        Alert dialogoInfo = new Alert(Alert.AlertType.INFORMATION);
        dialogoInfo.setTitle("Top 10 maiores pontuações");
        dialogoInfo.setHeaderText(
                "A pontuação leva em conta:\nNível de dificuldade escolhida\nTempo até acertar\nTentativa em que se acertou\n\nE é exibido pelos campos de: pontuação/modo/nome do jogador 1/adversário");

        dialogoInfo.setContentText(linha);
        dialogoInfo.showAndWait();
    }

    public void escreveRecordes(int quandoAcertou, int tempo) {
        try {
            File arquivo = new File("recordes.txt");
            FileWriter fw = new FileWriter(arquivo, true);
            BufferedWriter bw = new BufferedWriter(fw);

            String linha = tfNome.getText() + ";" + ((quandoAcertou * 9) + nivelDificuldade + tempo) + ";"
                    + quantJogagores + ";" + adver;

            bw.append("\n" + linha);
            bw.flush();
            bw.close();

        } catch (IOException x) {
            System.err.format("Erro de E/S: %s%n", x);
        }
    }

    public int getTempo(long tInic, long tFin) {
        long minutos = ((tFin - tInic) / 1000) / 60;
        if (minutos >= 0 && minutos <= 2) {
            return 63;
        } else if (minutos >= 3 && minutos <= 4) {
            return 55;
        } else if (minutos >= 5 && minutos <= 6) {
            return 47;
        } else if (minutos >= 7 && minutos <= 9) {
            return 40;
        } else if (minutos >= 10 && minutos <= 12) {
            return 33;
        } else if (minutos >= 13 && minutos <= 17) {
            return 27;
        } else {
            return 21;
        }

    }

    public static void main(String[] args) {
        Application.launch(args);
    }

}